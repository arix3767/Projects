package com.company;

public class BrakOsobException extends Exception {
    public BrakOsobException(String message) {
        super(message);
    }
}
